# ScreenInk (Android / Kotlin)

ScreenInk is a floating drawing/annotation overlay prototype for Android. It uses a `TYPE_APPLICATION_OVERLAY` window for the drawing surface and a compact, draggable, frosted-glass toolbar. The toolbar is 58 dp wide (roughly one-seventh of a typical  Android phone's width) and is vertically arranged to keep the content area visible.

## Requirements

- Android Studio Ladybug or newer
- JDK 17
- Android SDK Platform 35
- Android device/emulator running Android 8.0 (API 26) or newer

## Open and run

1. Extract `ScreenInk.zip` (or open this directory directly in Android Studio).
2. Let Gradle sync and install the Android SDK 35 platform if prompted.
3. Run the `app` configuration on a physical device.
4. Tap **Grant overlay permission** and enable **Display over other apps** in Android Settings.
5. Return to ScreenInk and tap **Start ScreenInk**.
6. Use the top switch button to switch between drawing mode and touch-through/interacting mode. Tap a tool to show its controls. Drag the toolbar to reposition it.

## Implemented in this project

- Foreground service with persistent notification and Android 14+ `specialUse` foreground-service declaration.
- Full-screen transparent drawing layer and compact draggable toolbar.
- Draw/interact toggle (drawing window becomes `FLAG_NOT_TOUCHABLE` in interact mode).
- Pen/brush/highlighter/eraser/laser and dot-laser input paths; undo and clear.
- Size, laser-length and highlighter-opacity sliders; preset color swatches; line-style and pen-style selectors.
- Basic circle/square/check/cross shape drawing and a symbols menu containing the requested symbol labels.
- Glass-style translucent panels, subtle borders, rounded corners and elevation.

## Known limitations before production release

This is a runnable foundation, not a fully production-certified release. In particular:

- **Area screenshot is not wired yet.** Android screen capture requires a user-approved `MediaProjection` session and a foreground service declared with the `mediaProjection` type. The toolbar button currently explains this instead of silently attempting capture. Implement the consent Activity, projection lifecycle, virtual display/ImageReader, crop selection, and MediaStore save flow before shipping.
- The custom color-spectrum control is currently a shortcut swatch, not a full HSV picker.
- The delay laser is represented by the same short-lived fading line as the line laser; a configurable trailing particle history can be added.
- The decorative symbol labels (star, question mark, fire, thumbs-up and exclamation) are present in the picker, while only circle, square, check and cross currently have geometric drawing paths.
- The eraser uses a clear blend mode; validate it on target OEM devices and consider storing strokes in a bitmap/layer for predictable erasing.
- The service uses `specialUse`, which must be justified in the Play Console foreground-service declaration. Google Play may reject a foreground-service use case that does not meet its policy.
- Add accessibility descriptions, persistent user preferences, automated tests, crash reporting, and OEM-specific lifecycle testing before publication.

## Project structure

```text
ScreenInk/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── .gitignore
├── README.md
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/screenink/app/
        │   ├── MainActivity.kt
        │   ├── OverlayService.kt
        │   ├── DrawView.kt
        │   └── SelectView.kt
        └── res/values/styles.xml
```

## Build from terminal

On a machine with Android SDK and JDK 17 configured:

```bash
gradle assembleDebug
```

This project archive does not include the Gradle wrapper JAR; Android Studio can open the project and sync with a locally installed compatible Gradle distribution. The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Git and GitHub

Create a new, empty repository on GitHub (do not initialize it with a README or license), then run these commands from this project directory:

```bash
git init
git add .
git commit -m "Initial ScreenInk Android app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ScreenInk.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username and use the exact repository URL GitHub displays. For a private repository, keep the repository private when creating it. GitHub authentication is normally done through a browser sign-in or a personal access token; do not put tokens in the remote URL or commit them.

## Zip the project yourself

From the parent directory:

```bash
zip -r ScreenInk.zip ScreenInk -x 'ScreenInk/.gradle/*' 'ScreenInk/.idea/*' 'ScreenInk/app/build/*'
```

## Platform notes

`SYSTEM_ALERT_WINDOW` is special app access: users must explicitly grant it in Settings. Android 14+ requires foreground-service types and their corresponding permissions. This project declares `specialUse` for its user-visible drawing overlay and includes the required subtype property; verify current Play policy before publishing.
