package com.screenink.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101522.toInt())
        }
        root.addView(TextView(this).apply {
            text = "ScreenInk"
            textSize = 30f
            setTextColor(0xFFF4F6FF.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Draw, highlight and annotate over any app. Grant overlay access, then start the floating toolbar."
            textSize = 15f
            setTextColor(0xFFB7C0D8.toInt())
            setPadding(0, 12, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission is already enabled", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Start ScreenInk"
            setOnClickListener { startOverlay() }
        })
        root.addView(TextView(this).apply {
            text = "Tip: the toolbar is intentionally narrow. Tap a tool to open its controls; use the switch at the top to pass touches through to the app underneath."
            textSize = 13f
            setTextColor(0xFF929DB8.toInt())
            setPadding(0, 22, 0, 0)
        })
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant overlay permission first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "ScreenInk started", Toast.LENGTH_SHORT).show()
        finish()
    }
}
