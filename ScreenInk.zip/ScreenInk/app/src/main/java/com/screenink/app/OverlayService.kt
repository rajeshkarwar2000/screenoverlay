package com.screenink.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.roundToInt

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.screenink.START"
        const val ACTION_STOP = "com.screenink.STOP"
        private const val CHANNEL_ID = "screenink_overlay"
        private const val NOTIFICATION_ID = 71
    }

    private lateinit var wm: WindowManager
    private lateinit var drawingView: DrawView
    private var drawingParams: WindowManager.LayoutParams? = null
    private var toolbar: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var drawingEnabled = true
    private var panelTool: DrawView.Tool? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf(); return
        }
        attachOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    private fun attachOverlay() {
        drawingView = DrawView(this)
        drawingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(drawingView, drawingParams)
        setDrawingTouch(true)
        buildToolbar()
    }

    private fun setDrawingTouch(enabled: Boolean) {
        drawingEnabled = enabled
        drawingParams?.let { p ->
            p.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (!enabled) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            try { wm.updateViewLayout(drawingView, p) } catch (_: Exception) { }
        }
    }

    private fun glass(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xE92B344C.toInt(), 0xD91A2235.toInt())
    ).apply {
        cornerRadius = dp(22).toFloat()
        setStroke(dp(1), 0x66FFFFFF)
    }

    private fun buildToolbar() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glass()
            setPadding(dp(5), dp(7), dp(5), dp(7))
            elevation = dp(14).toFloat()
        }
        val switch = toolButton("⇄", "Switch: draw / interact") {
            setDrawingTouch(!drawingEnabled)
            it.text = if (drawingEnabled) "✎" else "↗"
        }
        root.addView(switch)
        root.addView(separator())
        addTool(root, "⌁", "Laser") { openPanel(DrawView.Tool.LASER) }
        addTool(root, "✎", "Pen") { openPanel(DrawView.Tool.PEN) }
        addTool(root, "▰", "Brush") { openPanel(DrawView.Tool.BRUSH) }
        addTool(root, "▨", "Highlighter") { openPanel(DrawView.Tool.HIGHLIGHTER) }
        addTool(root, "⌫", "Eraser") { openPanel(DrawView.Tool.ERASER) }
        addTool(root, "◇", "Shapes") { openShapes() }
        root.addView(separator())
        addTool(root, "↶", "Undo") { drawingView.undo() }
        addTool(root, "⌧", "Clear") { drawingView.clear() }
        addTool(root, "▣", "Area screenshot") {
            Toast.makeText(this, "Area capture needs a MediaProjection approval flow; see README.", Toast.LENGTH_LONG).show()
        }
        addTool(root, "×", "Exit ScreenInk") { stopSelf() }

        val params = WindowManager.LayoutParams(
            dp(58), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(10); y = dp(100)
        }
        root.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y; moved = false; return false }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.abs(e.rawX-downX) > dp(5) || kotlin.math.abs(e.rawY-downY) > dp(5)) moved = true
                        if (moved) { params.x = (startX + downX - e.rawX).roundToInt(); params.y = (startY + e.rawY - downY).roundToInt(); wm.updateViewLayout(root, params); return true }
                    }
                }
                return false
            }
        })
        toolbar = root
        wm.addView(root, params)
    }

    private fun addTool(parent: LinearLayout, symbol: String, label: String, action: () -> Unit) {
        parent.addView(toolButton(symbol, label, action))
    }

    private fun toolButton(symbol: String, label: String, action: (TextView) -> Unit): TextView = TextView(this).apply {
        text = symbol; textSize = 22f; gravity = Gravity.CENTER
        setTextColor(0xFFF5F7FF.toInt()); contentDescription = label
        setBackgroundResource(android.R.drawable.list_selector_background)
        layoutParams = LinearLayout.LayoutParams(dp(46), dp(43)).apply { bottomMargin = dp(1) }
        setOnClickListener { action(this) }
    }

    private fun separator() = View(this).apply {
        setBackgroundColor(0x44FFFFFF)
        layoutParams = LinearLayout.LayoutParams(dp(34), dp(1)).apply { topMargin = dp(4); bottomMargin = dp(4) }
    }

    private fun openPanel(tool: DrawView.Tool) {
        if (panelTool == tool) { removePanel(); return }
        removePanel(); panelTool = tool
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glass(); setPadding(dp(14), dp(12), dp(14), dp(12)); elevation = dp(16).toFloat()
        }
        box.addView(TextView(this).apply { text = tool.name.replace('_',' '); textSize = 15f; setTextColor(Color.WHITE) })
        addSlider(box, "Size", 1, 40, drawingView.strokeWidth.roundToInt()) { drawingView.strokeWidth = it.toFloat() }
        when (tool) {
            DrawView.Tool.LASER -> {
                addSlider(box, "Length", 30, 500, drawingView.laserLength.roundToInt()) { drawingView.laserLength = it.toFloat() }
                addChoiceRow(box, listOf("Dot laser", "Line laser", "Delay laser")) { choice ->
                    drawingView.tool = if (choice == "Dot laser") DrawView.Tool.DOT_LASER else DrawView.Tool.LASER
                }
                addColors(box)
            }
            DrawView.Tool.PEN, DrawView.Tool.BRUSH -> {
                addColors(box)
                addChoiceRow(box, listOf("Continuous", "Dotted", "Spaced")) { drawingView.lineType = DrawView.LineType.valueOf(it.uppercase()) }
                addChoiceRow(box, listOf("Ball", "Natural", "Calligraphy")) { drawingView.penType = DrawView.PenType.valueOf(it.uppercase()) }
            }
            DrawView.Tool.HIGHLIGHTER -> {
                addColors(box)
                addSlider(box, "Opacity", 20, 220, drawingView.opacity) { drawingView.opacity = it }
            }
            DrawView.Tool.ERASER -> Unit
            else -> Unit
        }
        drawingView.tool = tool
        val p = WindowManager.LayoutParams(dp(230), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(72); y = dp(112) }
        panel = box; wm.addView(box, p)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
        parent.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(0xFFD7DDF0.toInt()); setPadding(0, dp(7), 0, 0) })
        parent.addView(SeekBar(this).apply { this.max = max-min; progress = (initial-min).coerceIn(0, max-min); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { changed(progress+min) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }) })
    }

    private fun addColors(parent: LinearLayout) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(4)) }
        val colors = listOf(0xFF222222.toInt(), 0xFFF4F4F4.toInt(), 0xFFFF5252.toInt(), 0xFFFFC107.toInt(), 0xFF4CAF50.toInt(), 0xFF2196F3.toInt(), 0xFFB388FF.toInt())
        colors.forEach { c ->
            val swatch = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(1), 0x99FFFFFF.toInt()) }
                setOnClickListener { drawingView.color = c }
            }
            row.addView(swatch, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(5) })
        }
        val spectrum = TextView(this).apply { text = "◉"; textSize = 20f; setTextColor(0xFFFFFFFF.toInt()); setOnClickListener { drawingView.color = 0xFF00BCD4.toInt(); Toast.makeText(this@OverlayService, "Spectrum shortcut: cyan selected", Toast.LENGTH_SHORT).show() } }
        row.addView(spectrum)
        parent.addView(row)
    }

    private fun addChoiceRow(parent: LinearLayout, choices: List<String>, selected: (String) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, 0) }
        choices.forEach { choice ->
            row.addView(TextView(this).apply {
                text = choice; textSize = 13f; setTextColor(0xFFE9EDFA.toInt()); setPadding(dp(8), dp(6), dp(8), dp(6))
                setOnClickListener { selected(choice); Toast.makeText(this@OverlayService, "$choice selected", Toast.LENGTH_SHORT).show() }
            })
        }
        parent.addView(row)
    }

    private fun openShapes() {
        removePanel()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        listOf("Circle", "Square", "Star", "Question mark", "Correct", "Wrong", "Fire", "Thumbs up", "Exclamatory mark").forEach { name ->
            box.addView(TextView(this).apply {
                text = name; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(8), dp(7), dp(8), dp(7))
                setOnClickListener {
                    drawingView.tool = DrawView.Tool.SHAPE
                    drawingView.shapeName = when (name) { "Correct" -> "Check"; "Wrong" -> "Cross"; else -> name }
                    removePanel()
                }
            })
        }
        val p = WindowManager.LayoutParams(dp(190), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.END; x = dp(72); y = dp(290) }
        panel = box; wm.addView(box, p)
    }

    private fun removePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null; panelTool = null }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "ScreenInk overlay", NotificationManager.IMPORTANCE_LOW).apply { description = "Keeps the drawing overlay active" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_edit)
        .setContentTitle("ScreenInk is running")
        .setContentText("Floating annotation toolbar is active")
        .setOngoing(true)
        .build()

    override fun onDestroy() {
        removePanel()
        toolbar?.let { try { wm.removeView(it) } catch (_: Exception) {} }; toolbar = null
        if (::drawingView.isInitialized) try { wm.removeView(drawingView) } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
