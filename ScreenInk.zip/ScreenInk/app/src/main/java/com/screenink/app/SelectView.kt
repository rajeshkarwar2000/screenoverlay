package com.screenink.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Selection surface used for choosing a rectangular region before a future capture flow. */
class SelectView(context: Context, private val onSelected: (RectF) -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8B9BFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val shade = Paint().apply { color = 0x55000000 }
    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var selecting = false

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0x55000000)
        if (selecting) {
            val rect = RectF(startX, startY, endX, endY).apply { sort() }
            canvas.drawRect(rect, Paint().apply { color = 0xAA101522.toInt(); style = Paint.Style.FILL })
            canvas.drawRect(rect, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { startX = event.x; startY = event.y; endX = event.x; endY = event.y; selecting = true; invalidate() }
            MotionEvent.ACTION_MOVE -> { endX = event.x; endY = event.y; invalidate() }
            MotionEvent.ACTION_UP -> {
                endX = event.x; endY = event.y; selecting = false
                val rect = RectF(startX, startY, endX, endY).apply { sort() }
                if (rect.width() > 12 && rect.height() > 12) onSelected(rect)
                invalidate()
            }
        }
        return true
    }
}
