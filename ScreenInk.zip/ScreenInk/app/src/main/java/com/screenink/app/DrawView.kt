package com.screenink.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class DrawView(context: Context) : View(context) {
    enum class Tool { PEN, BRUSH, HIGHLIGHTER, ERASER, LASER, DOT_LASER, SHAPE }
    enum class LineType { CONTINUOUS, DOTTED, SPACED }
    enum class PenType { BALL, NATURAL, CALLIGRAPHY }

    data class Stroke(
        val path: Path, val color: Int, val width: Float, val alpha: Int,
        val style: Paint.Style = Paint.Style.STROKE, val lineType: LineType = LineType.CONTINUOUS,
        val tool: Tool = Tool.PEN, val shape: String? = null
    )

    var tool = Tool.PEN
    var color = 0xFF8B9BFF.toInt()
    var strokeWidth = 5f
    var opacity = 110
    var lineType = LineType.CONTINUOUS
    var penType = PenType.BALL
    var shapeName = "Circle"
    var laserLength = 160f
    private val strokes = mutableListOf<Stroke>()
    private val undone = mutableListOf<Stroke>()
    private var activePath: Path? = null
    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var laserX = 0f
    private var laserY = 0f
    private var laserUntil = 0L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }

    fun undo() { if (strokes.isNotEmpty()) undone.add(strokes.removeAt(strokes.lastIndex)); invalidate() }
    fun clear() { strokes.clear(); undone.clear(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        strokes.forEach { drawStroke(canvas, it) }
        activePath?.let {
            val s = currentStroke(it)
            drawStroke(canvas, s)
        }
        if (tool == Tool.LASER || tool == Tool.DOT_LASER) {
            val remaining = (laserUntil - System.currentTimeMillis()).coerceAtLeast(0L)
            if (remaining > 0) {
                paint.style = Paint.Style.FILL
                paint.color = color
                paint.alpha = (255 * (remaining / 450f).coerceIn(0f, 1f)).toInt()
                if (tool == Tool.DOT_LASER) canvas.drawCircle(laserX, laserY, strokeWidth * 1.8f, paint)
                else canvas.drawLine(laserX, laserY, laserX + laserLength, laserY, paint.apply { style = Paint.Style.STROKE; strokeWidth = this@DrawView.strokeWidth * 2 })
                postInvalidateDelayed(16)
            }
        }
    }

    private fun currentStroke(path: Path) = Stroke(path, color, strokeWidth, if (tool == Tool.HIGHLIGHTER) opacity else 255,
        Paint.Style.STROKE, lineType, tool, if (tool == Tool.SHAPE) shapeName else null)

    private fun drawStroke(canvas: Canvas, stroke: Stroke) {
        paint.color = stroke.color
        paint.alpha = stroke.alpha
        paint.style = stroke.style
        paint.strokeWidth = if (stroke.tool == Tool.HIGHLIGHTER) stroke.width * 2.5f else stroke.width
        paint.pathEffect = when (stroke.lineType) {
            LineType.DOTTED -> android.graphics.DashPathEffect(floatArrayOf(1f, stroke.width * 2.3f), 0f)
            LineType.SPACED -> android.graphics.DashPathEffect(floatArrayOf(stroke.width * 1.5f, stroke.width * 2.5f), 0f)
            else -> null
        }
        if (stroke.tool == Tool.ERASER) { paint.color = 0x00000000; paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR) }
        if (stroke.shape != null) {
            val bounds = RectF(); stroke.path.computeBounds(bounds, true)
            when (stroke.shape) {
                "Square" -> canvas.drawRect(bounds, paint)
                "Circle" -> canvas.drawOval(bounds, paint)
                "Star" -> canvas.drawPath(stroke.path, paint)
                else -> canvas.drawPath(stroke.path, paint)
            }
        } else canvas.drawPath(stroke.path, paint)
        paint.xfermode = null; paint.pathEffect = null; paint.alpha = 255
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x; startY = event.y; lastX = event.x; lastY = event.y
                if (tool == Tool.LASER || tool == Tool.DOT_LASER) {
                    laserX = event.x; laserY = event.y; laserUntil = System.currentTimeMillis() + 450; invalidate(); return true
                }
                activePath = Path().apply { moveTo(event.x, event.y) }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (tool == Tool.LASER || tool == Tool.DOT_LASER) { laserX = event.x; laserY = event.y; laserUntil = System.currentTimeMillis() + 450; invalidate(); return true }
                activePath?.quadTo(lastX, lastY, (event.x + lastX) / 2f, (event.y + lastY) / 2f)
                lastX = event.x; lastY = event.y; invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                if (tool == Tool.LASER || tool == Tool.DOT_LASER) return true
                activePath?.let { path ->
                    if (tool == Tool.SHAPE) {
                        path.reset()
                        val l = min(startX, event.x); val t = min(startY, event.y)
                        val r = maxOf(startX, event.x); val b = maxOf(startY, event.y)
                        when (shapeName) {
                            "Check" -> { path.moveTo(l, (t+b)/2); path.lineTo((l+r)/2, b); path.lineTo(r, t) }
                            "Cross" -> { path.moveTo(l,t); path.lineTo(r,b); path.moveTo(r,t); path.lineTo(l,b) }
                            else -> { path.moveTo(l,t); path.lineTo(r,t); path.lineTo(r,b); path.lineTo(l,b); path.close() }
                        }
                    } else path.lineTo(event.x, event.y)
                    strokes.add(currentStroke(path)); undone.clear()
                }
                activePath = null; invalidate(); return true
            }
            MotionEvent.ACTION_CANCEL -> { activePath = null; invalidate(); return true }
        }
        return true
    }
}
